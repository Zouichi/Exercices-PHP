<?php
    require 'scripts/classes.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>TP PHP du 19/09</title>
</head>
<body>
    <?php
        $test1 = new factory('localhost','root','','test');
        $test2 = new factory('localhost','root','','test');
    ?>
</body>
</html>